self.__precacheManifest = [
  {
    "revision": "799f7c3b9ead4c65635ebfec63428e7d",
    "url": "/kar_releasestatic/media/male.799f7c3b.svg"
  },
  {
    "revision": "8cdd840b494c666e72d5d827c6c967d3",
    "url": "/kar_releasestatic/media/female.8cdd840b.svg"
  },
  {
    "revision": "5166cdd28a959c1c56dfba3fb60108e5",
    "url": "/kar_releasestatic/media/childgirl.5166cdd2.svg"
  },
  {
    "revision": "f403a58a79b0033de2be0cb6e75da4a2",
    "url": "/kar_releasestatic/media/childboy.f403a58a.svg"
  },
  {
    "revision": "264f9e4e7cec5d337ad6ef15b63feb7e",
    "url": "/kar_releasestatic/media/bg.264f9e4e.png"
  },
  {
    "revision": "7c1b667badc3fbcada86",
    "url": "/kar_releasestatic/js/runtime~main.1cdeaf1b.js"
  },
  {
    "revision": "32e7349968c806861013",
    "url": "/kar_releasestatic/js/main.2c70bbe7.chunk.js"
  },
  {
    "revision": "672a7db8ad111f7f0a5e",
    "url": "/kar_releasestatic/js/2.a00c53f2.chunk.js"
  },
  {
    "revision": "32e7349968c806861013",
    "url": "/kar_releasestatic/css/main.6a383031.chunk.css"
  },
  {
    "revision": "bb989488b2e3bb0b4f5c41b84a04c6f2",
    "url": "/kar_releaseindex.html"
  }
];