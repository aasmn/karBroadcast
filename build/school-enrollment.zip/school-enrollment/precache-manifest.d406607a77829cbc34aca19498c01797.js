self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9bdb2f38a03585e7680eb6a5a185a49c",
    "url": "/index.html"
  },
  {
    "revision": "fb16c6a2694e5b24ef3e",
    "url": "/static/css/main.3a0fbf85.chunk.css"
  },
  {
    "revision": "fb16c6a2694e5b24ef3e",
    "url": "/static/js/main.1e90249f.chunk.js"
  },
  {
    "revision": "aaf6915648a9b5188eb8",
    "url": "/static/js/runtime~main.fcb634ec.js"
  },
  {
    "revision": "2d03015341957639f7b4bf7f974e5ca8",
    "url": "/static/media/bg.2d030153.jpg"
  },
  {
    "revision": "423bdbb89d9f98672cc340f97b548d7d",
    "url": "/static/media/kuang1.423bdbb8.png"
  },
  {
    "revision": "6d975c85fd9eb447217b1e37839320cb",
    "url": "/static/media/kuang2.6d975c85.png"
  },
  {
    "revision": "c1e5981eda969f7f868f1835c69ba195",
    "url": "/static/media/kuangti.c1e5981e.png"
  }
]);